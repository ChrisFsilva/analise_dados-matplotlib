import pandas as pd
import matplotlib.pyplot as plt

# Ler o banco de dados e Atribuir banco de dados a variavel df
df = pd.read_csv ('TRAIN_TEST2.csv')

# Renomear as colunas do banco de dados
df.rename(columns={
    '2urvived':'Sobreviventes',
    'Pclass':'Classes',
    'Sex':'Sexo',
    'Age':'Idade',
    'Fare':'Tarifa'
},inplace = True)

# Excluir colunas que não serão utilizadas
    # O : aponta de qual linha quero a informação
    # O ~ vai reverter o comando
    # resultado do codigo, a variavel df = def.loc(Ela mesma)[todas as linhas(:), que NÃO (~) contenha na coluna (df.columns.str.contains) a palavra Zero ('zero')  ]
df = df.loc[:, ~df.columns.str.contains('zero')]

# criar um painel com vários graficos, definindo o tamanho
plt.figure(figsize = (20,6))
# Titulo do grafico
plt.title('Grafico de sobreviventes')

# Criando designer das telas (1 coluna, 3 colunas, posição 1)
plt.subplot(1,3,1)
# Atribuir na variavel taxa_sobrevivencia a media (mean) da coluna sobreviventes 
taxa_sobrevevivencia = df.groupby('Idade')['Sobreviventes'].mean().plot(kind= 'line')
# Adicionar o nome da label do grafico
plt.ylabel('Taxa de sobrevivencia')
plt.grid(True)

# Criando designer das telas (1 coluna, 3 colunas, posição 2)
plt.subplot(1,3,2)
# Atribuir a variavel sobrevivencia_sexo a media calculando os grupos sexo e sobreviventes
sobrevivencia_classe = df.groupby('Classes')['Sobreviventes'].mean()
richxpoor = sobrevivencia_classe.plot(kind = 'bar')
# Criando variavel para atribuir cor
colors = ['yellow', 'brown','black']
# Para cada barra do gráfico (barra) e cada cor da lista de cores (cor), pinte a barra com essa cor (variavel 'colors').”
for barra, cor in zip(richxpoor.patches, colors):
    #a barra receberá a cor pintada
    barra.set_color(cor)
# Adicionar o nome da label do grafico
plt.ylabel('Taxa de sobrevivencia por classe')

# Criando designer das telas (1 coluna, 3 colunas, posição 3)
plt.subplot(1,3,3)
# Atribuir a variavel sobrevivencia_sexo a media calculando os grupos sexo e sobreviventes, atribuindo o tipo de grafico em barra (plot(kind = 'bar'))
sobrevivencia_sexo = df.groupby('Sexo')['Sobreviventes'].mean()
# Atibuir o grafico a uma varivel
manxwoman = sobrevivencia_sexo.plot(kind = 'bar')
# Criando variavel para atribuir cor
colors = ['blue', 'red']
# Para cada barra do gráfico (barra) e cada cor da lista de cores (cor), pinte a barra com essa cor (variavel 'colors').”
for barra, cor in zip(manxwoman.patches, colors):
    #a barra receberá a cor pintada
    barra.set_color(cor)
# Adicionar o nome da label do grafico
plt.ylabel('Taxa de sobrevivencia por sexo')


plt.show()